#!/bin/bash

ROOT=/root/k8s-upgrade-deploy-2.14.3

rm -f $ROOT/deploy-docker/redflag/policycoreutils-3.1-6.p01.ky10.aarch64.rpm
