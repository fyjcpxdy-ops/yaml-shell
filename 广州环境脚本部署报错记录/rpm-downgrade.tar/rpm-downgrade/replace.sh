#!/bin/bash

ROOT=/root/k8s-upgrade-deploy-2.14.3
#ROOT=/root

rm -f $ROOT/deploy-ntp/centos7-2/*rpm
cp deploy-ntp/*rpm $ROOT/deploy-ntp/centos7-2/
